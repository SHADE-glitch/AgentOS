/**
 * opencode-aos-host — OpenCode Host Integration for Agent OS
 * 
 * Phase 6.0.2
 * 
 * This plugin integrates Agent OS with OpenCode as a Host.
 * It does NOT start a new OpenCode instance. It provides context to the current one.
 * 
 * Pipeline:
 *   OpenCode Plugin (this file)
 *     ↓ (calls adapter)
 *   AOS Host Adapter (Python)
 *     ↓ (calls existing AOS components)
 *   Router / Memory / Orchestrator
 *     ↓ (returns decision context)
 *   OpenCode Plugin
 *     ↓ (injects into system prompt)
 *   OpenCode Model (continues execution)
 * 
 * CRITICAL: No recursion. No new OpenCode instances.
 */

import { execFile } from "node:child_process";
import { promisify } from "node:util";

const execFileAsync = promisify(execFile);

// ── Configuration ────────────────────────────────────────────────
const AOS_ROOT = process.env.AGENT_OS_ROOT || "/home/shade/.agents";
const ADAPTER_PATH = `${AOS_ROOT}/runtime/hosts/opencode/aos_host_adapter.py`;
const PYTHON = process.env.PYTHON || "python3";

// Recursion guard environment variable
const RECURSION_ENV = "AOS_HOST_PLUGIN_ACTIVE";

// ── Adapter Call ─────────────────────────────────────────────────
async function callAOSAdapter(task, options = {}) {
  // Recursion guard
  if (process.env[RECURSION_ENV]) {
    console.error("[aos-host] Recursion detected, skipping AOS call");
    return null;
  }

  try {
    process.env[RECURSION_ENV] = "1";

    const args = [
      ADAPTER_PATH,
      task,
      "--json",
    ];

    if (options.sessionId) args.push("--session", options.sessionId);
    if (options.cwd) args.push("--cwd", options.cwd);
    if (options.model) args.push("--model", options.model);
    if (options.provider) args.push("--provider", options.provider);
    if (options.memoryMode) args.push("--memory", options.memoryMode);

    const { stdout, stderr } = await execFileAsync(PYTHON, args, {
      timeout: 30_000, // 30 second timeout
      env: {
        ...process.env,
        AOS_HOST_PLUGIN_ACTIVE: "1",
      },
    });

    if (stderr) {
      console.error("[aos-host] Adapter stderr:", stderr.slice(0, 200));
    }

    const context = JSON.parse(stdout.trim());
    return context;
  } catch (err) {
    console.error("[aos-host] Adapter call failed:", err);
    return null;
  } finally {
    delete process.env[RECURSION_ENV];
  }
}

// ── System Prompt Builder ────────────────────────────────────────
function buildSystemInjection(context) {
  const lines = [];

  lines.push("");
  lines.push("## Agent OS Decision Context");
  lines.push("");

  // Task classification
  const cls = context.decision?.classification;
  if (cls) {
    lines.push(`**Task Category**: ${cls.category}`);
    lines.push(`**Difficulty**: ${cls.difficulty}`);
    if (cls.roles?.length > 0) {
      lines.push(`**Recommended Role**: ${cls.roles[0]}`);
    }
  }

  // Memory
  if (context.memory?.retrieved > 0) {
    lines.push("");
    lines.push(`**Relevant Memories**: ${context.memory.retrieved} retrieved`);
    for (const mem of (context.memory.memories || []).slice(0, 3)) {
      lines.push(`- ${mem.memory_id}: ${(mem.content || "no content").slice(0, 100)}`);
    }
  }

  // Orchestration
  if (context.orchestration?.lead_agent && context.orchestration.lead_agent !== "general") {
    lines.push("");
    lines.push(`**Lead Agent Role**: ${context.orchestration.lead_agent}`);
  }

  // Warnings
  if (context.warnings?.length > 0) {
    lines.push("");
    lines.push("**Warnings**:");
    for (const w of context.warnings) {
      lines.push(`- ⚠ ${w}`);
    }
  }

  // Instructions
  if (context.instructions?.length > 0) {
    lines.push("");
    lines.push("**AOS Recommendations**:");
    for (const i of context.instructions) {
      lines.push(`- ${i}`);
    }
  }

  lines.push("");
  lines.push("Use this context to inform your approach. AOS does not execute tasks — it provides decision support.");
  lines.push("");

  return lines.join("\n");
}

// ── Plugin Export ────────────────────────────────────────────────
export const AosHostPlugin = async (ctx) => {
  // Cache for current session's last task context
  let lastContext = null;
  let lastPrompt = "";

  return {
    // Hook: intercept new messages
    "chat.message": async (input, output) => {
      // Only process user messages
      const userParts = output.parts.filter(
        (p) => p.type === "text" && p.text?.trim()
      );

      if (userParts.length === 0) return;

      const userText = userParts[0]?.text || "";
      if (!userText.trim()) return;

      // Skip if recursion is happening
      if (process.env[RECURSION_ENV]) return;

      // Call AOS adapter
      const context = await callAOSAdapter(userText, {
        sessionId: input.sessionID,
        cwd: ctx.directory,
      });

      if (context) {
        lastContext = context;
        lastPrompt = userText;
        console.log(
          `[aos-host] Task ${context.task_id}: status=${context.aos_status}, role=${context.orchestration?.lead_agent}`
        );
      }
    },

    // Hook: inject AOS context into system prompt
    "experimental.chat.system.transform": async (input, output) => {
      if (!lastContext) return;
      if (!lastContext.aos_status || lastContext.aos_status === "fallback") return;

      // Build context injection
      const injection = buildSystemInjection(lastContext);

      // Append to system prompt
      if (output.system.length > 0) {
        output.system[output.system.length - 1] += injection;
      } else {
        output.system.push(injection);
      }

      // Clear after injection
      lastContext = null;
      lastPrompt = "";
    },

    // Hook: log events for tracing
    event: async ({ event }) => {
      // Log session events for trace correlation
      if (event.type === "session.created") {
        console.log(`[aos-host] Session created: ${event.properties?.sessionID}`);
      }
    },

    // Cleanup
    dispose: async () => {
      lastContext = null;
      lastPrompt = "";
    },
  };
};

export default AosHostPlugin;
